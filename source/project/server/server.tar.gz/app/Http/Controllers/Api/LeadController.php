<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Services\Credentials;
use App\Services\LeadService;
use Exception;
use Illuminate\Http\Request;

class LeadController extends Controller
{
    private $leadService;

    public function __construct()
    {
        $this->leadService = new LeadService();
    }

    public function getInfo() {
        try {
            return response()->json(
                Credentials::getApiClient()->leads()->get(),
                200
            );
        } catch (Exception $e) {
            return response()->json(['message' => $e->getMessage()], isset($e->status) ? $e->status : 401);
        }
    }

    public function oneUpdate(Request $req)
    {
        try {
            $this->validate($req, [
                'lead_id' => 'required|min:3|max:6',
            ]);

            $data = [
                'leadId' => $req['lead_id'],
                'nameFilds' => $req['name_filds']
            ];
            return response()->json(
                $this->leadService->oneUpdate(...$data)->toArray(),
                200
            );
        } catch (Exception $e) {
            return response()->json(['message' => $e->getMessage()], isset($e->status) ? $e->status : 401);
        }
    }

    public function setLeadOne(Request $req)
    {
        try {
            $this->validate($req, [
                'name' => 'required|min:3|max:50',
            ]);

            $data = [
                'name' => $req['name'],
            ];
            return response()->json(
                $this->leadService->createLead(...$data)->toArray(),
                200
            );
        } catch (Exception $e) {
            return response()->json(['message' => $e->getMessage()], isset($e->status) ? $e->status : 401);
        }
    }
}
