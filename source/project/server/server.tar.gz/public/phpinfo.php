<?php

//echo var_dump(gd_info()); exit;
echo phpinfo(); exit;